# 互联网信息日报 - Linux 自包含版

**完全独立**：不需要系统 Python、不需要任何依赖、单个二进制搞定。

## 部署

```bash
tar xzf daily_report_linux_self_contained.tgz
cd linux/
chmod +x run.sh daily_report
./run.sh
```

## 文件结构

```
linux/
├── daily_report     (18MB 单文件二进制, 自带 Python + 11 依赖)
├── run.sh           (启动脚本)
└── rules.json       (规则配置)
```

## 使用

```bash
# 跑今天的
./run.sh

# 跑指定日期
./run.sh --date 2026-08-23

# 改输出目录
./run.sh --date 2026-08-23 --output /tmp/my_reports
```

## 系统要求

- **任意** Linux 发行版 (glibc 2.36+)
- 不需要 Python
- 不需要 pip
- 不需要任何第三方包

## 自动定时

```bash
# crontab -e
# 每天 17:30 自动跑
30 17 * * * cd /home/user/linux && ./run.sh >> /tmp/daily.log 2>&1
```

## 跨发行版兼容性

- 用 PyInstaller 6.x 静态打包
- 适用于 glibc 2.36+ (Debian 12+, Ubuntu 22.04+, CentOS 9+ 等)
- 目标机器不需要任何 Python 环境
