#!/bin/bash
# Daily Report - Linux 自包含版
# 无需任何系统环境 (不需要 python3, 不需要 site-packages)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "============================================"
echo " Daily Report (Self-Contained Mode)"
echo " Directory: $SCRIPT_DIR"
echo "============================================"
echo

# 检查 daily_report 是否存在
if [ ! -x "$SCRIPT_DIR/daily_report" ]; then
    echo "[ERROR] daily_report not found or not executable"
    echo "Please make sure daily_report binary is in the same directory"
    exit 1
fi

# 检查 rules.json
if [ ! -f "$SCRIPT_DIR/rules.json" ]; then
    echo "[ERROR] rules.json not found"
    exit 1
fi

# 跑 (默认今天, 可传 --date YYYY-MM-DD 改日期)
./daily_report "$@"
RC=$?

echo
echo "============================================"
if [ $RC -eq 0 ]; then
    echo " [OK] Report generated"
    echo " Check: reports/ folder"
else
    echo " [ERROR] Exit code: $RC"
fi
echo "============================================"
exit $RC
